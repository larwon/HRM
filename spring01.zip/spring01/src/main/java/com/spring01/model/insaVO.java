package com.spring01.model;

import java.sql.Date;
import java.util.List;



import lombok.Data;

@Data
public class insaVO {
	private Integer sabun;
	//@DateTimeFormat(pattern = "MM/dd/yyyy")
	private String joinday;
	//@DateTimeFormat(pattern = "MM/dd/yyyy")
	private String retireday;
	private String putyn;
	private String name;
	
	private String regno;
	private String engname;
	private String phone;
	private String hp;
	private String carrier;
	
	
	private String posgbncode;
	private String cmpregno;
	private String cmp_reg_image;
	private String sex;
	private int years;
	
	private String email;
	private Integer zip;
	private String addr1;
	private String addr2;
	private String deptcode;
	
	private String joingbncode;
	private String id;
	private String pwd;
	private String salary;
	private String kosaregyn;
	
	private String kosaclasscode;
	private String milyn;
	private String miltype;
	private String millevel;
	private String milstartdate;
	
	private String milenddate;
	private String jointype;
	private String gartlevel;
	private String selfintro;
	private String crmname;
	
	private String profile_image;
	private String carrier_image;
	
	private String test;
	private String test01;
	private String test02;
	private String keyword;
	
	private String savefile;
	private String carsaveFile;
	private String cmpsaveFile;
	private String fileName;
	private String carfileName;
	private String cmpfileName;
	
	/////////////////////////////////
	private int beginRecord;
	private int endRecord;
	private int page;
	
	private int totalRecord;
	
	private int totalPage;
	private int pagePerBlock;
	private int beginPage;
	private int endPage;
}
