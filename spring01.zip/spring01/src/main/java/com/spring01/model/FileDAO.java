package com.spring01.model;

import java.sql.SQLException;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface FileDAO {

	public int insertFile(FileVO fileVO) throws SQLException;

}
