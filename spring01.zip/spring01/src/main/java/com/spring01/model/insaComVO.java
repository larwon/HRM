package com.spring01.model;

import lombok.Data;

@Data
public class insaComVO {

	private String gubun;
	private String code;
	private String name;
	private String note;
}
