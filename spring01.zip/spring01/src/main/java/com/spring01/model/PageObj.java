package com.spring01.model;

import java.util.List;

import lombok.Data;

@Data
public class PageObj {
	
	
	private Integer stRow;
	private Integer enRow;
	
	private List<Integer> pageSetList;
	private Integer totalPage;
	
	//private Integer totalCnt;
	
	
	private Integer sabun;
	private String joinday;
	private String retireday;
	private String putyn;
	private String name;
	private String regno;
	private String posgbncode;
	private String salary;
	private String hp;
	private String jointype;
	private String joingbncode;
	
	
}
