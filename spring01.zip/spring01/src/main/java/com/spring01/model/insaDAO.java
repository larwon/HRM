package com.spring01.model;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface insaDAO {
	public int insertInsa(insaVO InsaVO) throws SQLException;
	
	public int sabunMax(Integer sabun) throws SQLException;
	
	public List<insaVO> getInsa(insaVO InsaVO) throws SQLException;

	//public List<insaVO> getKeyword(PageObj pageObj) throws SQLException;
	//public List<Map<String, Object>> getKeyword(PageObj pageObj) throws SQLException;
	//public List<insaVO> getKeyword(insaVO InsaVO) throws SQLException;
	
	//public int totalCount(PageObj pageObj) throws SQLException;
	
	//0922 페이징 연습
	public List<insaVO> getKeyword(insaVO InsaVO) throws SQLException;
	public int totalCount(insaVO InsaVO) throws SQLException;
	
	
	
	
	public List<insaComVO> joinGbnCode(insaComVO InsaComVO) throws SQLException;
	public List<insaComVO> sex(insaComVO InsaComVO) throws SQLException;
	public List<insaComVO> posGbnCode(insaComVO InsaComVO) throws SQLException;
	public List<insaComVO> deptCode(insaComVO InsaComVO) throws SQLException;
	public List<insaComVO> joinType(insaComVO InsaComVO) throws SQLException;
	public List<insaComVO> gartLevel(insaComVO InsaComVO) throws SQLException;
	public List<insaComVO> putYn(insaComVO InsaComVO) throws SQLException;
	public List<insaComVO> milType(insaComVO InsaComVO) throws SQLException;
	public List<insaComVO> milLevel(insaComVO InsaComVO) throws SQLException;
	public List<insaComVO> kosaRegYn(insaComVO InsaComVO) throws SQLException;
	public List<insaComVO> kosaClassCode(insaComVO InsaComVO) throws SQLException;
	
	public int insertFile(FileVO fileVO) throws SQLException;

	
	public insaVO insaModifyGET(Integer sabun) throws SQLException;
	//public insaVO possible(int sabun) throws SQLException;
	
	public int memberModifyPOST(insaVO InsaVO) throws SQLException;
	
	public int boardDelete (Integer sabun) throws SQLException;
	
}
