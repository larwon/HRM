package com.spring01.model;

import lombok.Data;

@Data
public class FileVO {

	private int sabun;
	private String fileName; 
	private String saveFile; 
	private String fileUrl;
	private String carfileName; 
	private String carsaveFile; 
	private String carfileUrl;
	private String cmpfileName; 
	private String cmpsaveFile; 
	private String cmpfileUrl;
}
