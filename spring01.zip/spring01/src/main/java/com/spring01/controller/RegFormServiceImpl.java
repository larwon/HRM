package com.spring01.controller;

import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.spring01.model.PageObj;
import com.spring01.model.insaComVO;
import com.spring01.model.insaDAO;
import com.spring01.model.insaVO;

@Service
public class RegFormServiceImpl implements RegFormService {

	@Autowired(required = false)
	insaDAO InsaDAO; 
	
	@Override
	public int insertInsa(insaVO InsaVO) throws SQLException {
		int cnt = InsaDAO.insertInsa(InsaVO);
		return cnt;
	}

	@Override
	public int sabunMax(Integer sabun) throws SQLException {
		int cnt = InsaDAO.sabunMax(sabun);
		return cnt;
	}

	
	@Override
	public List<insaVO> getInsa(insaVO InsaVO) throws SQLException {
		return InsaDAO.getInsa(InsaVO);
	}
	
	/*
	@Override
	public List<insaVO> getKeyword(insaVO InsaVO) throws SQLException {
		return InsaDAO.getKeyword(InsaVO);
	}
	*/
	/*
	@Override
	public List<insaVO> getKeyword(PageObj pageObj) throws SQLException {
		return InsaDAO.getKeyword(pageObj);
	}
	
	@Override
	public Integer totalCount(PageObj pageObj)  {
		return InsaDAO.totalCount(pageObj);
	}
	
	 
	
	@Override
	public List<Map<String, Object>> getKeyword(PageObj pageObj) throws SQLException {
		return InsaDAO.getKeyword(pageObj);
	}
	*/
	/*
	@Override
	public List<insaVO> getKeyword(PageObj pageObj) throws SQLException {
		return InsaDAO.getKeyword(pageObj);
	}
	*/
	/*
	@Override
	public int totalCount(PageObj pageObj) throws SQLException {
		return InsaDAO.totalCount(pageObj);
	}
	*/
//0922 페이징 연습

	@Override
	public List<insaVO> getKeyword(insaVO InsaVO) throws SQLException {
		return InsaDAO.getKeyword(InsaVO);
	}
	
	@Override
	public int totalCount(insaVO InsaVO) throws SQLException {
		return InsaDAO.totalCount(InsaVO);
	}
	
	
	
	@Override
	public List<insaComVO> joinGbnCode(insaComVO InsaComVO) throws SQLException {
		return InsaDAO.joinGbnCode(InsaComVO);
	}

	@Override
	public List<insaComVO> sex(insaComVO InsaComVO) throws SQLException {
		return InsaDAO.sex(InsaComVO);
	}

	@Override
	public List<insaComVO> posGbnCode(insaComVO InsaComVO) throws SQLException {
		return InsaDAO.posGbnCode(InsaComVO);
	}

	@Override
	public List<insaComVO> deptCode(insaComVO InsaComVO) throws SQLException {
		return InsaDAO.deptCode(InsaComVO);
	}

	@Override
	public List<insaComVO> joinType(insaComVO InsaComVO) throws SQLException {
		return InsaDAO.joinType(InsaComVO);
	}

	@Override
	public List<insaComVO> gartLevel(insaComVO InsaComVO) throws SQLException {
		return InsaDAO.gartLevel(InsaComVO);
	}

	@Override
	public List<insaComVO> putYn(insaComVO InsaComVO) throws SQLException {
		return InsaDAO.putYn(InsaComVO);
	}

	@Override
	public List<insaComVO> milType(insaComVO InsaComVO) throws SQLException {
		return InsaDAO.milType(InsaComVO);
	}

	@Override
	public List<insaComVO> milLevel(insaComVO InsaComVO) throws SQLException {
		return InsaDAO.milLevel(InsaComVO);
	}

	@Override
	public List<insaComVO> kosaRegYn(insaComVO InsaComVO) throws SQLException {
		return InsaDAO.kosaRegYn(InsaComVO);
	}

	@Override
	public List<insaComVO> kosaClassCode(insaComVO InsaComVO) throws SQLException {
		return InsaDAO.kosaClassCode(InsaComVO);
	}


	@Override
	public insaVO insaModifyGET(Integer sabun) throws SQLException {
		// TODO Auto-generated method stub
		return InsaDAO.insaModifyGET(sabun);
	}

	@Override
	public int memberModifyPOST(insaVO InsaVO) throws SQLException {
		// TODO Auto-generated method stub
		return InsaDAO.memberModifyPOST(InsaVO);
	}

	@Override
	public int boardDelete(Integer sabun) throws SQLException {
		// TODO Auto-generated method stub
		return InsaDAO.boardDelete(sabun);
	}
/*
	@Override
	public List<insaVO> getKeyword(Criteria cri) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
*/
	/*
	@Override
	public insaVO possible(int sabun) throws SQLException {
		// TODO Auto-generated method stub
		return InsaDAO.possible(sabun);
	}
	*/
/*
	@Override
	public int totalCount(Criteria cri) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}
	*/



}




	

	

