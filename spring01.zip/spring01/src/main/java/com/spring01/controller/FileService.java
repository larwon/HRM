package com.spring01.controller;

import java.sql.SQLException;

import com.spring01.model.FileVO;

public interface FileService {

	
	public int insertFile(FileVO fileVO) throws SQLException;
	
}
