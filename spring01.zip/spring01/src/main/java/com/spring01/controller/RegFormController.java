package com.spring01.controller;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;


import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;


import com.spring01.model.FileVO;

import com.spring01.model.PageObj;
import com.spring01.model.insaComVO;
import com.spring01.model.insaVO;


@Controller
public class RegFormController {
	
	@Autowired
	RegFormService regFormService;
	@Autowired
	FileService fileService;
	
	@GetMapping("index")
	public String index () {
		return "index";
	}
	
	
	
	@GetMapping("regform")
	public String GetRegform (insaVO InsaVO, insaComVO InsaComVO, Model model) throws SQLException {
		
		Integer sabun = regFormService.sabunMax(InsaVO.getSabun());
	    List<insaComVO> joinGbnCode = regFormService.joinGbnCode(InsaComVO);
	    List<insaComVO> sex = regFormService.sex(InsaComVO);
	    List<insaComVO> posGbnCode = regFormService.posGbnCode(InsaComVO);
	    List<insaComVO> deptCode = regFormService.deptCode(InsaComVO);
	    List<insaComVO> joinType = regFormService.joinType(InsaComVO);
	    List<insaComVO> gartLevel = regFormService.gartLevel(InsaComVO);
	    List<insaComVO> putYn = regFormService.putYn(InsaComVO);
	    List<insaComVO> milType = regFormService.milType(InsaComVO);
	    List<insaComVO> milLevel = regFormService.milLevel(InsaComVO);
	    List<insaComVO> kosaRegYn = regFormService.kosaRegYn(InsaComVO);
	    List<insaComVO> kosaClassCode = regFormService.kosaClassCode(InsaComVO);
	    
		
		model.addAttribute("joinGbnCode", joinGbnCode);
		model.addAttribute("sex", sex);
		model.addAttribute("posGbnCode", posGbnCode);
		model.addAttribute("deptCode", deptCode);
		model.addAttribute("joinType", joinType);
		model.addAttribute("gartLevel", gartLevel);
		model.addAttribute("putYn", putYn);
		model.addAttribute("milType", milType);
		model.addAttribute("milLevel", milLevel);
		model.addAttribute("kosaRegYn", kosaRegYn);
		model.addAttribute("kosaClassCode", kosaClassCode);
		model.addAttribute("sabun", sabun);
		return "reg_form";
	}


	
	
	@PostMapping("regform")
		public String insertProductpost(insaVO InsaVO,Model model, @RequestParam("profileimage") MultipartFile files,
				@RequestParam("carrierimage") MultipartFile files1,
				@RequestParam("cmpregimage") MultipartFile files2, HttpServletRequest request) throws IllegalStateException, IOException, Exception {
			
	/*
				String fileName = files.getOriginalFilename();
				String fileNameExtension = FilenameUtils.getExtension(fileName).toLowerCase();
				File destinationFile;
				String destinationFileName;
				String fileName1 = files1.getOriginalFilename();
				String fileNameExtension1 = FilenameUtils.getExtension(fileName1).toLowerCase();
				File destinationFile1;
				String destinationFileName1;
				String fileName2 = files2.getOriginalFilename();
				String fileNameExtension2 = FilenameUtils.getExtension(fileName2).toLowerCase();
				File destinationFile2;
				String destinationFileName2;
				
				String fileUrl = "C:\\dev\\workspace\\spring01\\src\\main\\resources\\static\\img";
				String fileUrl1 = "C:\\dev\\workspace\\spring01\\src\\main\\resources\\static\\img";
				String fileUrl2 = "C:\\dev\\workspace\\spring01\\src\\main\\resources\\static\\img";
				do {
					destinationFileName = RandomStringUtils.randomAlphanumeric(32) + "." + fileNameExtension;
					destinationFile = new File(fileUrl + destinationFileName);
					destinationFileName1 = RandomStringUtils.randomAlphanumeric(32) + "." + fileNameExtension1;
					destinationFile1 = new File(fileUrl1 + destinationFileName1);
					destinationFileName2 = RandomStringUtils.randomAlphanumeric(32) + "." + fileNameExtension2;
					destinationFile2 = new File(fileUrl2 + destinationFileName2);
				} while (destinationFile.exists());
				
				destinationFile.getParentFile().mkdirs();
				files.transferTo(destinationFile);
				destinationFile1.getParentFile().mkdirs();
				files1.transferTo(destinationFile1);
				destinationFile2.getParentFile().mkdirs();
				files2.transferTo(destinationFile2);
				regFormService.insertInsa(InsaVO);
				
				FileVO file = new FileVO();
				
				file.setSabun(InsaVO.getSabun());
				file.setFileName(destinationFileName);
				file.setSaveFile(fileName);
				file.setFileUrl(fileUrl);
				file.setCarfileName(destinationFileName1);
				file.setCarsaveFile(fileName1);
				file.setCarfileUrl(fileUrl1);
				file.setCmpfileName(destinationFileName2);
				file.setCmpsaveFile(fileName2);
				file.setCmpfileUrl(fileUrl2);
				fileService.insertFile(file);
		*/		
			
		
		return "insa_list";
	}
	
	
	
	@GetMapping("insalist")
	public String insalist (insaVO InsaVO, insaComVO InsaComVO, Model model) throws Exception {
	
		List<insaComVO> joinType = regFormService.joinType(InsaComVO);
		List<insaComVO> putYn = regFormService.putYn(InsaComVO);
		List<insaComVO> posGbnCode = regFormService.posGbnCode(InsaComVO);
		List<insaComVO> joinGbnCode = regFormService.joinGbnCode(InsaComVO);
		
	
		//model.addAttribute("getKeyword", getKeyword);
		
		model.addAttribute("joinType", joinType);
		model.addAttribute("putYn", putYn);
		model.addAttribute("posGbnCode", posGbnCode);
		model.addAttribute("joinGbnCode", joinGbnCode); 


		List<insaVO> getKeyword = regFormService.getKeyword(InsaVO);
		

		model.addAttribute("getKeyword", getKeyword);
		
		
		return "insa_list";
	}
	
	
//	@PostMapping("insalist")
//	public String postInsaList (insaVO InsaVO, insaComVO InsaComVO, String keyword, 
	//		@RequestParam(name="page", defaultValue = "1") Integer page,
	//		Model model) throws Exception{
		
		
		//	      List<insaVO> getKeyword = regFormService.getKeyword(InsaVO);
			
	//		       model.addAttribute("getKeyword", getKeyword);
		
	//	return "insa_list";
//	}
	
// 0919 페이징 1차	
	/*
	 * @GetMapping("dolist") public String doList (@RequestParam(name="page",
	 * defaultValue = "1") , insaVO InsaVO, insaComVO InsaComVO, Model model) throws
	 * Exception{
	 */
		  
	
	@GetMapping("dolist")
	public String doList (insaVO InsaVO, insaComVO InsaComVO, Model model) throws Exception{
 

		List<insaVO> getKeyword = regFormService.getKeyword(InsaVO);
		

		model.addAttribute("getKeyword", getKeyword);

		return "insa_list :: #list";
	}
	
	/*
	 * public String doList (@RequestParam(name="page", defaultValue = "1") Integer page, 
			insaVO InsaVO, Model model) throws Exception{
		
		
		  PageObj pageObj = new PageObj();  
		
		  Integer pageRow = 5;
	      Integer pageSetSize = 5;  
	      
	      Integer stRow = page <= 1 ? 0 : (page-1) * pageRow;
	      Integer edRow = pageRow;
	      

	      pageObj.setStRow(stRow);
	      pageObj.setEnRow(edRow);
	      
	      
	      //System.out.println(edRow);
	      
	      List<insaVO> getKeyword = regFormService.getKeyword(insaVO);
	      
	      Integer totalCount = regFormService.totalCount(pageObj);
	      Integer totalPage = (int)Math.ceil((double)totalCount / pageRow);
	      Integer curPageSet = (int)Math.ceil((double)page / pageSetSize);
	      
	      List<Integer> pageSetList = new ArrayList<Integer>();
	      
	      Integer curPageSetSt = curPageSet-1 == 0 ? 1 : (curPageSet-1)*pageSetSize+1;
	      
	      for (int i = curPageSetSt; i <= curPageSet*pageSetSize; i++) {
	         if (totalPage<i) break;
	            pageSetList.add(i);
	      }

	      pageObj.setPageSetList(pageSetList);
	      pageObj.setTotalPage(totalPage);
	      
	      model.addAttribute("pageObj", pageObj);
		  model.addAttribute("getKeyword", getKeyword);
		   
		   //model.addAttribute("pageObj1", pageObj.getPageSetList());
		   //model.addAttribute("pageObj2", pageObj.getTotalPage());
		return "insa_list :: #list";
	}
	 */
	@PostMapping("doregform")
	public String doregform ( insaVO InsaVO, Model model) throws Exception {
		
		
	
		regFormService.insertInsa(InsaVO);
		
		return "reg_form :: #list";
	}
	
	@PostMapping("doupdate")
	public String doupdate (insaVO InsaVO, Model model) throws Exception {
		

		regFormService.memberModifyPOST(InsaVO);

		return "reg_form :: #list";
	}
	/*
	@PostMapping("/dodoupdate")
	public String dodoupdate (insaVO InsaVO, Model model) throws Exception {
		

		regFormService.memberModifyPOST(InsaVO);

		return "reg_formup :: #list";
	}
	*/
	
	
	
	
	
	/*
	@GetMapping("list")
	public String list (insaVO InsaVO, insaComVO InsaComVO, String keyword, 
			@RequestParam(name="page", defaultValue = "1") Integer page,
			Model model) throws Exception{
		
		
				PageObj pageObj = new PageObj();
				pageObj.setKeyword(keyword);
			
				  pageObj.setKeyword(keyword);
		
			      Integer pageRow = 5;
			      Integer pageSetSize = 5;
			      
			    
			      
			      Integer stRow = page <= 1 ? 0 : (page-1) * pageRow;
			      Integer edRow = pageRow;
			      

			      pageObj.setStRow(stRow);
			      pageObj.setEnRow(edRow);
			      

			      //List<insaVO> getKeyword = regFormService.getKeyword(pageObj);
			      
			      Integer totalCount = regFormService.totalCount(pageObj);
			      Integer totalPage = (int)Math.ceil((double)totalCount / pageRow);
			      Integer curPageSet = (int)Math.ceil((double)page / pageSetSize);
			      
			      List<Integer> pageSetList = new ArrayList<Integer>();
			      
			      Integer curPageSetSt = curPageSet-1 == 0 ? 1 : (curPageSet-1)*pageSetSize+1;
			      
			      for (int i = curPageSetSt; i <= curPageSet*pageSetSize; i++) {
			         if (totalPage<i) break;
			            pageSetList.add(i);
			      }

			       pageObj.setPageSetList(pageSetList);
			       pageObj.setTotalPage(totalPage);

			
			       //model.addAttribute("getKeyword", getKeyword);
			       model.addAttribute("pageObj", pageObj);
			       
			       return "list";
		
	}
	*/
	
	/*
	@GetMapping("insaModify/{sabun}")
	public String insaModifyGET(@PathVariable("sabun") Integer sabun,
			insaVO InsaVO, Model model, HttpServletRequest request) throws Exception {
		
		insaVO insa = regFormService.insaModifyGET(sabun);
		
		model.addAttribute("insa", insa);
		
		return "reg_formup";
	}
	
	@PostMapping("insaModify/{sabun}")
	public String insaModifyPOST(@PathVariable("sabun") Integer sabun,
			insaVO InsaVO, Model model, HttpServletRequest request) throws Exception {
		
		//List<insaVO> insa = regFormService.memberModifyPOST(InsaVO);
		
		//model.addAttribute("insa", insa);
		
		return "redirect:insaModify/" + InsaVO.getSabun();
	}	
	*/
	/*
	@GetMapping("insaModify/{sabun}")
	public String insaModifyGet(@PathVariable("sabun") Integer sabun,
			insaVO InsaVO, insaComVO InsaComVO, Model model) throws Exception {
		
	    List<insaComVO> joinGbnCode = regFormService.joinGbnCode(InsaComVO);
	    List<insaComVO> sex = regFormService.sex(InsaComVO);
	    List<insaComVO> posGbnCode = regFormService.posGbnCode(InsaComVO);
	    List<insaComVO> deptCode = regFormService.deptCode(InsaComVO);
	    List<insaComVO> joinType = regFormService.joinType(InsaComVO);
	    List<insaComVO> gartLevel = regFormService.gartLevel(InsaComVO);
	    List<insaComVO> putYn = regFormService.putYn(InsaComVO);
	    List<insaComVO> milType = regFormService.milType(InsaComVO);
	    List<insaComVO> milLevel = regFormService.milLevel(InsaComVO);
	    List<insaComVO> kosaRegYn = regFormService.kosaRegYn(InsaComVO);
	    List<insaComVO> kosaClassCode = regFormService.kosaClassCode(InsaComVO);
	    
		
		model.addAttribute("joinGbnCode", joinGbnCode);
		model.addAttribute("sex", sex);
		model.addAttribute("posGbnCode", posGbnCode);
		model.addAttribute("deptCode", deptCode);
		model.addAttribute("joinType", joinType);
		model.addAttribute("gartLevel", gartLevel);
		model.addAttribute("putYn", putYn);
		model.addAttribute("milType", milType);
		model.addAttribute("milLevel", milLevel);
		model.addAttribute("kosaRegYn", kosaRegYn);
		model.addAttribute("kosaClassCode", kosaClassCode);
			
			insaVO insa = regFormService.insaModifyGET(sabun);
			
			model.addAttribute("insa", insa);
			
		return "reg_formup";
	}
	*/
	
	@GetMapping("/insaModify/{sabun}")
	//@GetMapping("insaModify/{sabun}")
	public String insaModify(@PathVariable("sabun") Integer sabun,
			insaVO InsaVO, insaComVO InsaComVO, Model model) throws Exception {
		
	    List<insaComVO> joinGbnCode = regFormService.joinGbnCode(InsaComVO);
	    List<insaComVO> sex = regFormService.sex(InsaComVO);
	    List<insaComVO> posGbnCode = regFormService.posGbnCode(InsaComVO);
	    List<insaComVO> deptCode = regFormService.deptCode(InsaComVO);
	    List<insaComVO> joinType = regFormService.joinType(InsaComVO);
	    List<insaComVO> gartLevel = regFormService.gartLevel(InsaComVO);
	    List<insaComVO> putYn = regFormService.putYn(InsaComVO);
	    List<insaComVO> milType = regFormService.milType(InsaComVO);
	    List<insaComVO> milLevel = regFormService.milLevel(InsaComVO);
	    List<insaComVO> kosaRegYn = regFormService.kosaRegYn(InsaComVO);
	    List<insaComVO> kosaClassCode = regFormService.kosaClassCode(InsaComVO);
	    
		
		model.addAttribute("joinGbnCode", joinGbnCode);
		model.addAttribute("sex", sex);
		model.addAttribute("posGbnCode", posGbnCode);
		model.addAttribute("deptCode", deptCode);
		model.addAttribute("joinType", joinType);
		model.addAttribute("gartLevel", gartLevel);
		model.addAttribute("putYn", putYn);
		model.addAttribute("milType", milType);
		model.addAttribute("milLevel", milLevel);
		model.addAttribute("kosaRegYn", kosaRegYn);
		model.addAttribute("kosaClassCode", kosaClassCode);
			
		insaVO insa = regFormService.insaModifyGET(sabun);
			
			model.addAttribute("insa", insa);
			
		return "reg_formup";
	}
	
	@PutMapping("/insaModify/{sabun}")
	public String insaModifyPost( @PathVariable("sabun") Integer sabun,
			insaVO InsaVO, insaComVO InsaComVO, Model model) throws Exception {
		
		
		List<insaComVO> joinGbnCode = regFormService.joinGbnCode(InsaComVO);
	    List<insaComVO> sex = regFormService.sex(InsaComVO);
	    List<insaComVO> posGbnCode = regFormService.posGbnCode(InsaComVO);
	    List<insaComVO> deptCode = regFormService.deptCode(InsaComVO);
	    List<insaComVO> joinType = regFormService.joinType(InsaComVO);
	    List<insaComVO> gartLevel = regFormService.gartLevel(InsaComVO);
	    List<insaComVO> putYn = regFormService.putYn(InsaComVO);
	    List<insaComVO> milType = regFormService.milType(InsaComVO);
	    List<insaComVO> milLevel = regFormService.milLevel(InsaComVO);
	    List<insaComVO> kosaRegYn = regFormService.kosaRegYn(InsaComVO);
	    List<insaComVO> kosaClassCode = regFormService.kosaClassCode(InsaComVO);
	    
	
	    //regFormService.memberModifyPOST(InsaVO);
	
			
	    
	    
		model.addAttribute("joinGbnCode", joinGbnCode);
		model.addAttribute("sex", sex);
		model.addAttribute("posGbnCode", posGbnCode);
		model.addAttribute("deptCode", deptCode);
		model.addAttribute("joinType", joinType);
		model.addAttribute("gartLevel", gartLevel);
		model.addAttribute("putYn", putYn);
		model.addAttribute("milType", milType);
		model.addAttribute("milLevel", milLevel);
		model.addAttribute("kosaRegYn", kosaRegYn);
		model.addAttribute("kosaClassCode", kosaClassCode);
		
		regFormService.memberModifyPOST(InsaVO);
	
		return "redirect:" + InsaVO.getSabun();
	}

	@DeleteMapping("/insadelete/{sabun}")
	public String delete(@PathVariable("sabun") Integer sabun, insaVO InsaVO) throws Exception{
		regFormService.boardDelete(sabun);
		return "redirect:/insalist";
	}
}
