package com.spring01.controller;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring01.model.FileDAO;
import com.spring01.model.FileVO;
import com.spring01.model.insaDAO;

@Service
public class FileServiceImpl implements FileService{

	@Autowired
	insaDAO fileDAO;
	
	@Override
	public int insertFile(FileVO fileVO) throws SQLException {
		// TODO Auto-generated method stub
		return fileDAO.insertFile(fileVO);
	}

}
